Parts.c invokes 4 parts:
	diskinfo 
	disklist
	diskget 
	diskput

Note* Have asked for an extension so the assignment is still incomplete. 

There are many warnings but disklist, diskinfo, diskget & diskput all complie
