#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h> 
#include <limits.h>
#include <assert.h>
#include <time.h> 
#include <netinet/in.h> //Internet Protocal Family 

struct __attribute__((__packed__)) superblock_t{
	uint8_t fs_id [8];
	uint16_t block_size; 
	uint32_t file_system_block_count;
	uint32_t fat_start_block; 
	uint32_t fat_block_count;
	uint32_t root_dir_start_block; 
	uint32_t root_dir_block_count; 
};

struct __attribute__((__packed__)) dir_entry_timedate_t {
	uint16_t year;
	uint8_t month;
	uint8_t day;
	uint8_t hour;
	uint8_t minute;
	uint8_t second;
}; 

struct __attribute__((__packed__))dir_entry_t {
	uint8_t status;
	uint32_t starting_block;
	uint32_t block_count; 
	uint32_t size; 
	struct dir_entry_timedate_t modify_time;
	struct dir_entry_timedate_t create_time;
	uint8_t filename[31];
	uint8_t unused[6];
};

int main(int argc, char* argv[]){

#if defined(PART1)
	diskinfo(argc,argv);
#elif defined(PART2)
	disklist(argc,argv);
#elif defined(PART3)
	diskget(argc,argv);
#elif defined(PART4)
	diskput(argc,argv);
#else
#	error"part[1234] must be defined"
#endif
	return 0; 
}

//Will first convert integer values to Big Endian before writing to disk.
int diskinfo(int argc, char* argv[]){

	if (argc < 2) {
		printf("Please put ./diskinfo <file> \n");
		exit(1);
	}
	int fp = open(argv[1],O_RDWR);
	if(fp < 0) { 
		printf("Error opening file\n");
		exit(1);
	} 
	
	struct stat buf;
	fstat(fp, &buf);
	
	void* add = mmap(NULL,buf.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fp, 0);
	
	if(add == MAP_FAILED){
		printf("Map Failed\n");
		exit(1);
	}
	
//Superblock Information
struct superblock_t* sb;
sb=(struct superblock_t*)add;

//Blocksize 
int blocksize;
blocksize = ntohs(sb->block_size);

//Gets the block count 	
int fssize; 
fssize = ntohl(sb->file_system_block_count);

//Gets the FAT start blcok
int fstart; 
fstart = ntohl(sb->fat_start_block);

//Gets FAT block count
int fblocks;
fblocks = ntohl(sb->fat_block_count);

//Gets where the root starts
int rootstart;
rootstart = ntohl(sb->root_dir_start_block);
//rootstart = superblock(p,22,4); 

//Gets the directroy block count
int rootdir;
rootdir = ntohl(sb->root_dir_block_count); 


//Troubleshooting helpers
/*
int fatstartblock;
fatstartblock=p+fstart*blocksize;
printf("%x\n",fatstartblock);

int length = ntohl(fblocks);
printf("%d\n",length);
*/

int i;
int j;

//unsigned int *temp = malloc(sizeof(unsigned int));

int ffree; //FAT free blocks
int fres; //FAT reserved blocks
int falloc; //FAT allocated blcoks 

int start = fstart*blocksize;
int end = start + blocksize*fblocks;

//To get FAT information
for(i=start;i<=end; i+=4){
	int temp; //=(int)malloc(sizeof(int)*4);
	for(j=0;j<(blocksize/4);j++){
		temp=memcpy(&temp,add+start,4);
		start+=4;
	}
		if(temp==0){
			ffree++;
		}else if(temp==1){
			fres++;
		}else{
			falloc++;
		}
//	start+=4;
}

//free(temp);

//File Size 
//printf("Filesize: %x\n",buf.st_size);

printf("Super block information: \n");
printf("Block size: %d\n", blocksize);
printf("Block count: %d\n",fssize); 
printf("FAT starts: %d\n",fstart);
printf("FAT blocks: %d\n",fblocks);
printf("Root directory start: %d\n",rootstart);
printf("Root directory blocks: %d\n", rootdir);
printf("\n");
printf("FAT information: \n");
printf("Free Blocks:%d\n",ntohl(ffree));
printf("Reserved Blocks: %d\n",ntohl(fres));
printf("Allocated Blocks: %d\n",ntohl(falloc));

	munmap(add,buf.st_size); 
	close(fp); 
	return 0; 
}

int disklist(int argc, char* argv[]){

char* fd;

	if (argc < 2){ 
		printf("Please put ./disklist <file> \n");
		exit(1); 
	}
	int fp = open(argv[1],O_RDWR);
	if(fp < 0) {
		printf("Error opening file\n");
		exit(1);
	}
	struct stat buf;

	fstat(fp, &buf);

 	char* add=mmap(NULL,buf.st_size,PROT_READ, MAP_PRIVATE, fp,0);
	if(add==MAP_FAILED){
		printf("map failed\n");
		exit(1);
	}
	
	struct superblock_t* se;
	se=(struct superblock_t*)add;
       
        struct dir_entry_t* sb;
	sb=(struct dir_entry_t*)add; 	

	struct dir_entry_timedate_t* st;
	st=(struct dir_entry_timedate_t*)add;
	
	int rootstart;
	rootstart = ntohl(se->root_dir_start_block);

	int blocksize;
	blocksize = ntohl(se->block_size);
	
	int rootdir; 
	rootdir = ntohl(se->root_dir_block_count);

	int size;	
	int i;

//	char *root = (char*)malloc(sizeof(char) * 64);
//	char *data;

	for(i=0;i<rootdir;i++){
//		data = memcpy(root, p + blocksize*i, 64);	
	char* name = malloc(sizeof(char));
	int k;
	for(k = 0; k < 8; k++){
		name[i] = add[i];
	}
	if((add[0] & 0x02) == 0x02){
		fd = "F";

	}else if((add[0] & 0x04) == 0x04){
		fd = "D";
	}
	
	size = sb->size;

	int year = st->year;
	int month = st->month;
	int day = st->day;
	int hour = st->hour;
	int minute = st->minute;
	int second = st->second;

	printf("%s %10d %30s %d/%d/%d %02d:%02d:%02d\n",fd,size,name,year,month,day,hour,minute,second);		
	add += 64;
	}
//	free(data);        
//	p+=64;
/*	
printf("%s",fd);
printf(" ");
printf("%d",size);
printf(" ");
printf("%s",name);
printf(" ");
printf("%s\n",ctime(&buf.st_mtime));
*/	
	munmap(add,buf.st_size);
	close(fp);
	return 0;
}

int diskget(int argc, char* argv[]){ 
		
	int curfile; 
//	int desfile; 

	FILE *fp;

	if (argc < 4){ 
		printf("Please put ./diskget file1 /sub_dir/file2 file2 \n");
		exit(1); 
	}
	
	fp = open(argv[1],O_RDONLY); 
	
	if (fp < 0){
		printf("Error opening file \n");
		exit(1);
	}
	
	struct stat buf; 
	fstat(fp, &buf); 

 	void* add=mmap(NULL,buf.st_size,PROT_READ, MAP_PRIVATE, fp,0);
	if(add==MAP_FAILED){
		printf("map failed\n");
		exit(1);
	}
	
	//Seeing if the file is found or not
	curfile = open(argv[2], O_RDWR); 
		
		if(curfile < 0){
			printf("Error getting current file \n"); 
			close(fp);
			exit(1);
		}	
		
/*	desfile = open(argv[3], O_CREAT | O_WRONLY);

		if(desfile < 0){
			printf("Error getting destination file \n"); 
			exit(1);
		}
*/	
	munmap(add,buf.st_size);			
	return 0;
	


}
int diskput(int argc, char* argv[]){
	if(argc < 2){ 
		printf("Please put ./diskput <file> \n");
		exit(1); 
	} 
	return 0;
}


