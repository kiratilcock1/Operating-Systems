
/* Kira Tilcock 
V00810384
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <time.h>
#include <sys/time.h>  
#include <unistd.h>
#include <signal.h>


#define MAX_SIZE 1000

pthread_mutex_t bridge = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t queue = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t conv = PTHREAD_COND_INITIALIZER;
pthread_t threads[MAX_SIZE]; 

typedef struct train{
  int id;
  char direction;
  int atime;
  int ctime;
  int priority;
  char status;      // AW = All Waiting, A= Arrived at station
} train;

train trainlist[MAX_SIZE];
struct timeval start;
struct timeval end;
void *func(void *obj);


void *func(void *obj){

train* t = (train*)obj;
//usleep(t.atime * 100000);

}


int main(int argc, char *argv[]){
  
  gettimeofday(&start, NULL);

  char *a;
  int num;
  char lines[MAX_SIZE][MAX_SIZE];
  char buffer[10];
  int i;
  char content[MAX_SIZE][MAX_SIZE];
  void *Status;

  if(argc <2){
    printf("Please pass through a textfile");
    return (1);
  }

  FILE *fp = fopen(argv[1], "r");
  if(fp == 0){
    printf("Error Opening File\n");
    return (1);
  }

  //Read in the trains
  //fgets(buffer,sizeof(buffer),fp);
  num = atoi(content[0]);

  int id; 
  char direction;
  int atime; 
  int ctime; 
   
  while(fgets(content[i],sizeof(buffer), fp)){
      train t;
      t.id = i;
      strcpy(lines[i], content[i]);
      //a = strtok(NULL," "); 
      //t.direction == (char)a;
      //a = strtok(NULL," ");
      //t.atime = atoi(a);
      //a = strtok(NULL," ");
     // t.ctime = atoi(a);
      trainlist[i]=t;
      i++;
  }

  //create thread for each train
  int j;
  for (j = 0; j < num; j++) {
    if (pthread_create(&threads[i], NULL, func, (void*)&trainlist[i]) != 0){
      printf("Error: failed to create pthread.\n");
      exit(1);
    }
  }



  //wait for all of the threads to terminate
  int k;
  for(k = 0; k < num; k++){
        pthread_join(threads[k], NULL);
  }

//  printf("Number: %d\n\n", trainlist) ;

  fclose(fp);

  printf("Number of Trains: %d\n",i);

  pthread_exit(NULL);

  return (0);
}