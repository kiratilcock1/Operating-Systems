CSC360 Assignment 2

MTS.c is a program that given an input schedules each train, based upon priority, arrival time and crossing time. 
i
My initial design has been modified, as there were errors and it was not as flesh out. The algorithm has changed the most and the following are the modifications:

1.Have added another mutex for the queue  


The Algorithm is as follows:

Within main()
1. Grab input file, and calculate the number of trains within the file 
2. Create a thread and one convar for each train from the input file 

Within Thread() (all functions that process threads) 
1. Load trains 
2. Set each train to its appropriate priority and direction 
3. Once complete will try to lock the bridge
4. The dispatcher will send each train across the tracks

Handling signals and status:

There are two signalling methods:
	1. Single to == AW (all-waiting) to signal that all the trains have been successfully loaded.This is done by having a count of how many "lines" are and then having a global variable called count that will hold the value of the number of trains within the file. Once that number is equal to the size of the file, signal will now equal AW.   
	2. Once a thread has arrive at its stations its status will go to A (Arrived)
