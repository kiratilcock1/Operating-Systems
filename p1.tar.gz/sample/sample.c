#include <stdio.h>
#include <string.h>
#include "readline/readline.h"
#include "readline/history.h"
#include <stdlib.h>
#include <unistd.h> 
#include <errno.h> 

/*Kira Tilcock 
V00810384 
This program exuctes a unix shell */

//Global struct 
typedef struct node { 
	pid_t pid;
	int id; 
	int curstate;
	struct node *next;

} node; 

//List is inteailized as empty 
struct node* head = NULL;
struct node n;

int main()
{
	int argc; 
	char* argv[100];
	char cwd[1024];
	const char* prompt = "SSI: %s %s";
	
	//Prints out what this program implements and what the Makefile implements 
	printf("About this program:\n --------------------------- \n Makefile:\n make --> compiles to the program \n make clean --> removes outfiles\n -------------------------------- \n The Shell Implements:\n ls \n exit: exit, ctrl+d, ctrl +c, ctrl+z \n pwd \n cd: [absolute], [relative],..,~,/ \n mkdir \n rmdir \n cp \n mv \n rm \n chmod \n sleep \n man \n More than one command:  \n ls -l , ls -l -a \n  --------------------------------\n"); 

	int bailout = 0;
	while (!bailout) {
			
		getcwd(cwd,1024);
		printf(prompt,cwd,">");
		
		//read in input 		
		char a[1024];
		char* reply = readline(a);
		
		if (!strcmp(reply, "bye")){ 
			bailout = 1; 	
		}
		// Tokenize input, put reading in the imput and each input seperated by a space is seperated into a token 
		char *token; 
		token = strtok(reply," "); 

		argv[0]=token; 
		int i = 0; 
		while(argv[i]!=NULL){ 
			argv[i+1] = strtok(NULL," "); 
			i++;
		}

		//global list of running process
		if(!strcmp(argv[0],"bglist")){
			return 1;		
			//print list 
		}
		
		//If the user inputs "exit" the shell will terminate 
		if(!strcmp(argv[0],"exit")) exit(0);
	
		//Sets environment to be the home directory of the user
        	char *homedir = getenv("HOME");        
		
		//If the user imputs "cd" the program will change the directory 
		if(!strcmp(argv[0],"cd")){
			if(((argv[1]==NULL)||(strcmp(argv[1],"~")==0))){
				chdir(homedir);
			}else{
				 chdir(argv[1]);
			}	
		}
		//If the user wants to execute a background process as well 
		if(!strcmp(argv[0],"bg")){
			return 1;
		}
		
		//execute user input 
		if(execute(argv) == 0) break;
			
		//Space for reply 
		free(reply);
	}
}
/* Attept to run backgroud process

//adding new nodes (processes) to the list, by inserting the new process in the front of the list

void add(char command, pid_t pid){
	//new node
	struct node* new_node  = (struct node*)malloc(sizeof(struct node));
	//put in
	new_node->pid = pid;
	new_node->command = command; 
	//next of new node head 
	new_node->next = NULL;
	
	//If list is empty the new node is set to head
	if(head == NULL){
		head = new_node;
	}else{
		node* a = head; 

	}
	//head points to new node
	head = new_node;

}
//delete process once completed 
void delete(pid_t pid){

	//If list is empty
	if(isempty()){ 
		return;
	}
	
	//remove head if the last process needs to be removed
	struct node* temp = head;
	head = temp->next;
	free(temp);
	
	//get privous node to set as head
	temp = temp->next;

	struct node* next = temp->next->next;
	free(temp->next);
	
	//unlink node from list 
	temp->next=next;
}
int isempty(node *node){
	if(!node){
		return 1; 
	}else{
		return 0;
	} 
}

//print all process within the struct 
void print_process(struct node* n){
	int i = 0; 
	for(i;i<sizeof(argv);i++){
		printf("[%d] ",n[i].pid); 
	}	
	printf("Total background jobs: %d",i);
}
 */

int execute(char** argv)
{
	//fork process
	pid_t pid; 
	pid = fork();
	int bg;
	int status; 
	
	//if the child process fails
	if (pid < 0){ 
		printf("Child fail"); 
		return 1;
	}

	// exicute child process and if background process to implemented handeled here
	else if (pid == 0 && bg == 0){
		//Implement print child process to make sure the child process is running
		//printf("Child Process\n");		
		//Excute command
		setpgid(pid,0);
		execvp(argv[0],argv);
		//Error occured
		return 0; 

	}
	else if(pid==0){
		execvp(argv[0],argv);
	}

	//parent process
	
	else if(pid > 0) {
		// wait for child proccess to finish 
		int childstatus; 
		waitpid(pid, &childstatus,WUNTRACED);
		return 1;
	} 
			
	return 0; 
} 
